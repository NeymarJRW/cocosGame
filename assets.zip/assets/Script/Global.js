var Switch = require("Switch");
window.Global = {
    skillIndex: 0,
    win:false,
    destoryEnemy:0,
    autoCreateEnemy:false,
    Switch
};